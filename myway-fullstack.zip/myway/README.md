# Myway — AI Career Mentorship Platform

A full-stack Next.js 14 application with real authentication, AI career coaching (Claude API), PostgreSQL database, and role-based dashboards.

---

## 🚀 Quick Start (Step by Step)

### Step 1 — Install Node.js
Download from: https://nodejs.org (choose LTS version)
Verify: open terminal and run `node --version`

### Step 2 — Open this folder in VS Code
1. Open VS Code
2. File → Open Folder → select the `myway` folder

### Step 3 — Install dependencies
Open the VS Code terminal (Ctrl + `) and run:
```bash
npm install
```

### Step 4 — Set up your database (Supabase — FREE)
1. Go to https://supabase.com and create a free account
2. Click "New Project" → fill in name and password
3. Go to Settings → Database → copy the "URI" connection string
4. It looks like: `postgresql://postgres:[YOUR-PASSWORD]@db.xxx.supabase.co:5432/postgres`

### Step 5 — Get your Claude API key
1. Go to https://console.anthropic.com
2. Click API Keys → Create Key
3. Copy the key (starts with `sk-ant-`)

### Step 6 — Create your .env.local file
In VS Code, create a new file called `.env.local` in the myway folder and paste:
```
DATABASE_URL="your-supabase-connection-string-here"
NEXTAUTH_SECRET="any-random-long-string-here-change-this"
NEXTAUTH_URL="http://localhost:3000"
ANTHROPIC_API_KEY="sk-ant-your-key-here"
```

### Step 7 — Set up the database tables
```bash
npm run db:push
```
This creates all the tables in your Supabase database automatically.

### Step 8 — Run the app!
```bash
npm run dev
```
Open your browser and go to: **http://localhost:3000**

---

## 📁 Project Structure

```
myway/
├── prisma/
│   └── schema.prisma       ← Database tables (edit to add fields)
├── src/
│   ├── app/
│   │   ├── page.tsx                     ← Login/Signup page
│   │   ├── layout.tsx                   ← Root layout
│   │   ├── globals.css                  ← All styles
│   │   ├── dashboard/
│   │   │   ├── page.tsx                 ← Redirects by role
│   │   │   ├── student/page.tsx         ← Student dashboard
│   │   │   ├── employer/page.tsx        ← Employer dashboard
│   │   │   └── counselor/page.tsx       ← Counselor dashboard
│   │   └── api/
│   │       ├── auth/
│   │       │   ├── [...nextauth]/route.ts  ← Auth handler
│   │       │   └── register/route.ts       ← User registration
│   │       ├── chat/route.ts            ← Claude AI streaming
│   │       ├── jobs/route.ts            ← List + post jobs
│   │       ├── jobs/[id]/apply/route.ts ← Apply for job
│   │       └── resume/route.ts          ← Save/load resumes
│   ├── components/
│   │   ├── AuthProvider.tsx      ← Wraps app with session
│   │   ├── Navbar.tsx            ← Top navigation
│   │   ├── ChatInterface.tsx     ← Real AI chat (streaming)
│   │   ├── JobBoard.tsx          ← Browse + apply to jobs
│   │   ├── ResumeBuilder.tsx     ← Build + print resume
│   │   ├── PostJobForm.tsx       ← Employer job posting
│   │   └── StudentStats.tsx      ← Application stats
│   └── lib/
│       ├── auth.ts        ← NextAuth configuration
│       ├── claude.ts      ← Claude AI setup
│       └── prisma.ts      ← Database client
└── .env.example           ← Template for your .env.local
```

---

## 🌐 Deploy to the Internet (FREE)

### Deploy on Vercel
1. Push this folder to GitHub (create free account at github.com)
2. Go to https://vercel.com and sign in with GitHub
3. Click "Import Project" → select your repo
4. Add your environment variables from `.env.local`
5. Click Deploy — your site will be live in ~2 minutes!

---

## ✨ Features

| Feature | Status |
|---|---|
| Real login / signup with email + password | ✅ |
| Role-based dashboards (Student / Employer / Counselor) | ✅ |
| AI career coach powered by Claude (streaming) | ✅ |
| Real job board with search and filters | ✅ |
| Job application tracking | ✅ |
| Live resume builder with print/PDF | ✅ |
| Employer job posting | ✅ |
| PostgreSQL database (Supabase) | ✅ |

---

## 🛠️ Common Commands

| Command | What it does |
|---|---|
| `npm run dev` | Start the development server |
| `npm run build` | Build for production |
| `npm run db:push` | Sync database schema |
| `npm run db:studio` | Open database viewer (Prisma Studio) |

---

## 💡 Need Help?
- Next.js docs: https://nextjs.org/docs
- Prisma docs: https://www.prisma.io/docs
- NextAuth docs: https://next-auth.js.org
- Claude API docs: https://docs.anthropic.com
