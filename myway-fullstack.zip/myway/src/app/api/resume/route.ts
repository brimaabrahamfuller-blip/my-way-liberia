import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

// GET: Fetch user's resumes
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const resumes = await prisma.resume.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json(resumes);
}

// POST: Save a resume
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const { name, data, id } = body;

    if (id) {
      // Update existing
      const updated = await prisma.resume.update({
        where: { id },
        data: { name, data },
      });
      return NextResponse.json(updated);
    } else {
      // Create new
      const resume = await prisma.resume.create({
        data: {
          name: name || "My Resume",
          data,
          userId: (session.user as any).id,
        },
      });
      return NextResponse.json(resume, { status: 201 });
    }
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
