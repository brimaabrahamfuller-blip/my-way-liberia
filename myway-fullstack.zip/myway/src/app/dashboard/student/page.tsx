import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ChatInterface from "@/components/ChatInterface";
import JobBoard from "@/components/JobBoard";
import ResumeBuilder from "@/components/ResumeBuilder";
import StudentStats from "@/components/StudentStats";

export default async function StudentDashboard() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") redirect("/");

  const userId = (session.user as any).id;
  const applications = await prisma.application.findMany({
    where: { userId },
    include: { job: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <Navbar user={session.user} />
      <main style={{ maxWidth: "1200px", margin: "0 auto", padding: "2rem 5%" }}>
        <h1 style={{ fontSize: "1.8rem", fontWeight: 700, marginBottom: "0.5rem" }}>
          Welcome back, {session.user?.name?.split(" ")[0]} 👋
        </h1>
        <p style={{ color: "var(--text-light)", marginBottom: "2rem" }}>
          Your career journey continues here.
        </p>

        <StudentStats applications={applications} />

        {/* Tabs */}
        <StudentTabs userId={userId} applications={applications} />
      </main>
    </div>
  );
}

function StudentTabs({ userId, applications }: { userId: string; applications: any[] }) {
  return (
    <div>
      {/* Section: AI Career Coach */}
      <section style={{ marginBottom: "2.5rem" }}>
        <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
          🤖 AI Career Coach
        </h2>
        <ChatInterface userId={userId} />
      </section>

      {/* Section: Job Board */}
      <section style={{ marginBottom: "2.5rem" }}>
        <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
          💼 Browse Jobs
        </h2>
        <JobBoard userId={userId} />
      </section>

      {/* Section: My Applications */}
      <section style={{ marginBottom: "2.5rem" }}>
        <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
          📋 My Applications
        </h2>
        {applications.length === 0 ? (
          <div className="card-item" style={{ textAlign: "center", padding: "2rem", color: "var(--text-light)" }}>
            You haven&apos;t applied to any jobs yet. Browse jobs above!
          </div>
        ) : (
          <table className="w-full bg-white rounded-xl overflow-hidden shadow-sm">
            <thead>
              <tr style={{ borderBottom: "1px solid #eee", background: "#f9f9f9" }}>
                <th className="p-4 text-left text-sm font-semibold">Job</th>
                <th className="p-4 text-left text-sm font-semibold">Company</th>
                <th className="p-4 text-left text-sm font-semibold">Date</th>
                <th className="p-4 text-left text-sm font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {applications.map(app => (
                <tr key={app.id} style={{ borderBottom: "1px solid #eee" }}>
                  <td className="p-4 font-medium">{app.job.title}</td>
                  <td className="p-4 text-gray-500">{app.job.company}</td>
                  <td className="p-4 text-gray-500 text-sm">
                    {new Date(app.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <span className={`status-pill status-${app.status}`}>{app.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* Section: Resume Builder */}
      <section style={{ marginBottom: "2.5rem" }}>
        <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
          📄 Resume Builder
        </h2>
        <ResumeBuilder userId={userId} />
      </section>
    </div>
  );
}
