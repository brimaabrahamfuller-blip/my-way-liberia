import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import PostJobForm from "@/components/PostJobForm";

export default async function EmployerDashboard() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "EMPLOYER") redirect("/");

  const userId = (session.user as any).id;
  const jobs = await prisma.job.findMany({
    where: { postedById: userId },
    include: { _count: { select: { applications: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <Navbar user={session.user} />
      <main style={{ maxWidth: "1200px", margin: "0 auto", padding: "2rem 5%" }}>
        <h1 style={{ fontSize: "1.8rem", fontWeight: 700, marginBottom: "0.5rem" }}>
          Employer Dashboard
        </h1>
        <p style={{ color: "var(--text-light)", marginBottom: "2rem" }}>
          Post jobs and manage your candidates.
        </p>

        {/* Stats */}
        <div className="dashboard-grid" style={{ marginBottom: "2rem" }}>
          <div className="card-item" style={{ textAlign: "center" }}>
            <p style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>Active Jobs</p>
            <p style={{ fontSize: "2rem", fontWeight: 800, color: "var(--primary-color)" }}>
              {jobs.filter(j => j.isActive).length}
            </p>
          </div>
          <div className="card-item" style={{ textAlign: "center" }}>
            <p style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>Total Applications</p>
            <p style={{ fontSize: "2rem", fontWeight: 800, color: "var(--primary-color)" }}>
              {jobs.reduce((sum, j) => sum + j._count.applications, 0)}
            </p>
          </div>
        </div>

        {/* Post Job */}
        <section style={{ marginBottom: "2.5rem" }}>
          <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
            ➕ Post a New Job
          </h2>
          <PostJobForm />
        </section>

        {/* My Jobs */}
        <section>
          <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
            📋 My Job Listings
          </h2>
          {jobs.length === 0 ? (
            <div className="card-item" style={{ textAlign: "center", color: "var(--text-light)", padding: "2rem" }}>
              No jobs posted yet.
            </div>
          ) : (
            <div className="dashboard-grid">
              {jobs.map(job => (
                <div key={job.id} className="job-card">
                  <span className={`status-pill ${job.isActive ? "status-accepted" : "status-declined"}`}>
                    {job.isActive ? "Active" : "Closed"}
                  </span>
                  <h3 style={{ marginTop: "10px", marginBottom: "5px" }}>{job.title}</h3>
                  <p style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>{job.location} · {job.type}</p>
                  <p style={{ marginTop: "10px", fontWeight: 600, color: "var(--primary-color)" }}>
                    {job._count.applications} applicant{job._count.applications !== 1 ? "s" : ""}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
