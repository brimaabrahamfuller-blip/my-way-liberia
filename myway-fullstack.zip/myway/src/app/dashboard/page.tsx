import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) redirect("/");

  const role = (session.user as any).role;

  if (role === "STUDENT") redirect("/dashboard/student");
  if (role === "EMPLOYER") redirect("/dashboard/employer");
  if (role === "COUNSELOR") redirect("/dashboard/counselor");

  redirect("/");
}
