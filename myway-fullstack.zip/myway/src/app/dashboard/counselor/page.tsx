import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Navbar from "@/components/Navbar";
import ChatInterface from "@/components/ChatInterface";

export default async function CounselorDashboard() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "COUNSELOR") redirect("/");

  const userId = (session.user as any).id;
  const studentCount = await prisma.user.count({ where: { role: "STUDENT" } });
  const jobCount = await prisma.job.count({ where: { isActive: true } });

  return (
    <div>
      <Navbar user={session.user} />
      <main style={{ maxWidth: "1200px", margin: "0 auto", padding: "2rem 5%" }}>
        <h1 style={{ fontSize: "1.8rem", fontWeight: 700, marginBottom: "0.5rem" }}>
          Counselor Dashboard
        </h1>
        <p style={{ color: "var(--text-light)", marginBottom: "2rem" }}>
          Guide students and monitor the platform.
        </p>

        {/* Platform stats */}
        <div className="dashboard-grid" style={{ marginBottom: "2.5rem" }}>
          <div className="card-item" style={{ textAlign: "center" }}>
            <p style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>Total Students</p>
            <p style={{ fontSize: "2rem", fontWeight: 800, color: "var(--primary-color)" }}>{studentCount}</p>
          </div>
          <div className="card-item" style={{ textAlign: "center" }}>
            <p style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>Active Jobs</p>
            <p style={{ fontSize: "2rem", fontWeight: 800, color: "var(--primary-color)" }}>{jobCount}</p>
          </div>
        </div>

        {/* AI Coach (counselors can use it too) */}
        <section>
          <h2 style={{ fontSize: "1.3rem", fontWeight: 700, marginBottom: "1rem" }}>
            🤖 AI Career Research Tool
          </h2>
          <p style={{ color: "var(--text-light)", marginBottom: "1rem", fontSize: "0.9rem" }}>
            Use the AI to research industry trends, prepare student guidance materials, or test advice.
          </p>
          <ChatInterface userId={userId} />
        </section>
      </main>
    </div>
  );
}
