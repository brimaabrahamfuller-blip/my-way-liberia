"use client";
import { useState } from "react";

interface ResumeData {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  summary: string;
  experience: string;
  education: string;
  skills: string;
}

export default function ResumeBuilder({ userId }: { userId: string }) {
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [data, setData] = useState<ResumeData>({
    fullName: "",
    email: "",
    phone: "",
    location: "",
    summary: "",
    experience: "",
    education: "",
    skills: "",
  });

  function update(field: keyof ResumeData, value: string) {
    setData(prev => ({ ...prev, [field]: value }));
    setSaved(false);
  }

  async function saveResume() {
    setSaving(true);
    try {
      await fetch("/api/resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: `${data.fullName || "My"} Resume`, data }),
      });
      setSaved(true);
    } catch {
      alert("Could not save resume");
    }
    setSaving(false);
  }

  function printResume() {
    window.print();
  }

  const inputStyle = {
    width: "100%",
    padding: "10px 12px",
    border: "1px solid #dfe6e9",
    borderRadius: "8px",
    fontSize: "0.9rem",
    marginBottom: "12px",
  };

  const textareaStyle = {
    ...inputStyle,
    minHeight: "80px",
    resize: "vertical" as const,
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "30px", alignItems: "start" }}>
      {/* Editor */}
      <div className="card-item">
        <h3 style={{ marginBottom: "1rem", fontSize: "1rem", fontWeight: 700 }}>
          ✏️ Edit Your Resume
        </h3>

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Full Name</label>
        <input style={inputStyle} value={data.fullName} onChange={e => update("fullName", e.target.value)} placeholder="Your full name" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Email</label>
        <input style={inputStyle} value={data.email} onChange={e => update("email", e.target.value)} placeholder="email@example.com" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Phone</label>
        <input style={inputStyle} value={data.phone} onChange={e => update("phone", e.target.value)} placeholder="+250 7XX XXX XXX" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Location</label>
        <input style={inputStyle} value={data.location} onChange={e => update("location", e.target.value)} placeholder="Kigali, Rwanda" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Professional Summary</label>
        <textarea style={textareaStyle} value={data.summary} onChange={e => update("summary", e.target.value)} placeholder="A brief description of yourself and career goals..." />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Work Experience</label>
        <textarea style={textareaStyle} value={data.experience} onChange={e => update("experience", e.target.value)} placeholder="Job Title at Company (Year - Year)&#10;• Key achievement&#10;• Key achievement" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Education</label>
        <textarea style={textareaStyle} value={data.education} onChange={e => update("education", e.target.value)} placeholder="Degree in Field - University Name (Year)" />

        <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-light)" }}>Skills</label>
        <input style={inputStyle} value={data.skills} onChange={e => update("skills", e.target.value)} placeholder="JavaScript, Python, Communication, Leadership..." />

        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={saveResume} disabled={saving} className="btn-primary" style={{ flex: 1 }}>
            {saving ? "Saving..." : saved ? "✓ Saved" : "Save Resume"}
          </button>
          <button
            onClick={printResume}
            style={{
              flex: 1,
              padding: "14px",
              background: "transparent",
              border: "1px solid var(--primary-color)",
              color: "var(--primary-color)",
              borderRadius: "8px",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            🖨️ Print / PDF
          </button>
        </div>
      </div>

      {/* Live Preview */}
      <div
        id="resume-preview"
        style={{
          background: "white",
          padding: "40px",
          boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
          borderRadius: "4px",
          fontSize: "12px",
          color: "#333",
          minHeight: "500px",
        }}
      >
        <h1 style={{ color: "var(--primary-color)", fontSize: "22px", borderBottom: "2px solid var(--secondary-color)", paddingBottom: "8px", marginBottom: "12px" }}>
          {data.fullName || "Your Name"}
        </h1>
        <p style={{ color: "#666", marginBottom: "4px" }}>
          {[data.email, data.phone, data.location].filter(Boolean).join("  ·  ")}
        </p>

        {data.summary && (
          <>
            <h2 style={{ fontSize: "13px", textTransform: "uppercase", marginTop: "16px", borderBottom: "1px solid #eee", paddingBottom: "4px", marginBottom: "8px" }}>
              Summary
            </h2>
            <p style={{ lineHeight: "1.6" }}>{data.summary}</p>
          </>
        )}

        {data.experience && (
          <>
            <h2 style={{ fontSize: "13px", textTransform: "uppercase", marginTop: "16px", borderBottom: "1px solid #eee", paddingBottom: "4px", marginBottom: "8px" }}>
              Experience
            </h2>
            <pre style={{ fontFamily: "inherit", whiteSpace: "pre-wrap", lineHeight: "1.6" }}>{data.experience}</pre>
          </>
        )}

        {data.education && (
          <>
            <h2 style={{ fontSize: "13px", textTransform: "uppercase", marginTop: "16px", borderBottom: "1px solid #eee", paddingBottom: "4px", marginBottom: "8px" }}>
              Education
            </h2>
            <p style={{ lineHeight: "1.6" }}>{data.education}</p>
          </>
        )}

        {data.skills && (
          <>
            <h2 style={{ fontSize: "13px", textTransform: "uppercase", marginTop: "16px", borderBottom: "1px solid #eee", paddingBottom: "4px", marginBottom: "8px" }}>
              Skills
            </h2>
            <p style={{ lineHeight: "1.8" }}>
              {data.skills.split(",").map(s => s.trim()).join("  ·  ")}
            </p>
          </>
        )}
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden; }
          #resume-preview, #resume-preview * { visibility: visible; }
          #resume-preview { position: absolute; left: 0; top: 0; width: 100%; box-shadow: none; }
        }
        @media (max-width: 900px) {
          div[style*="gridTemplateColumns"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
