"use client";
import { useState, useEffect } from "react";

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  description: string;
  salary?: string;
  createdAt: string;
  _count: { applications: number };
}

export default function JobBoard({ userId }: { userId: string }) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState<string | null>(null);
  const [applied, setApplied] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchJobs();
  }, [search, typeFilter]);

  async function fetchJobs() {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (typeFilter) params.set("type", typeFilter);
    const res = await fetch(`/api/jobs?${params}`);
    const data = await res.json();
    setJobs(data);
    setLoading(false);
  }

  async function applyToJob(jobId: string) {
    setApplying(jobId);
    try {
      const res = await fetch(`/api/jobs/${jobId}/apply`, { method: "POST" });
      if (res.ok) {
        setApplied(prev => new Set([...prev, jobId]));
      } else {
        const data = await res.json();
        alert(data.error || "Could not apply");
      }
    } catch {
      alert("Something went wrong");
    }
    setApplying(null);
  }

  return (
    <div>
      {/* Search + Filter */}
      <div style={{ display: "flex", gap: "12px", marginBottom: "20px", flexWrap: "wrap" }}>
        <input
          type="text"
          placeholder="Search jobs, companies, locations..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ flex: 1, minWidth: "200px", padding: "12px", border: "1px solid #dfe6e9", borderRadius: "8px" }}
        />
        <select
          value={typeFilter}
          onChange={e => setTypeFilter(e.target.value)}
          style={{ padding: "12px", border: "1px solid #dfe6e9", borderRadius: "8px" }}
        >
          <option value="">All Types</option>
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Remote">Remote</option>
          <option value="Internship">Internship</option>
        </select>
      </div>

      {/* Job Grid */}
      {loading ? (
        <p style={{ textAlign: "center", color: "var(--text-light)", padding: "2rem" }}>
          Loading jobs...
        </p>
      ) : jobs.length === 0 ? (
        <p style={{ textAlign: "center", color: "var(--text-light)", padding: "2rem" }}>
          No jobs found. Try a different search.
        </p>
      ) : (
        <div className="dashboard-grid">
          {jobs.map(job => (
            <div key={job.id} className="job-card">
              <span
                style={{
                  display: "inline-block",
                  padding: "4px 10px",
                  background: "#e1f0ff",
                  color: "var(--primary-color)",
                  borderRadius: "20px",
                  fontSize: "0.75rem",
                  fontWeight: 700,
                  marginBottom: "12px",
                }}
              >
                {job.type}
              </span>
              <h3 style={{ marginBottom: "8px", fontSize: "1.1rem" }}>{job.title}</h3>
              <p style={{ color: "var(--text-light)", fontSize: "0.9rem", marginBottom: "4px" }}>
                🏢 {job.company}
              </p>
              <p style={{ color: "var(--text-light)", fontSize: "0.9rem", marginBottom: "4px" }}>
                📍 {job.location}
              </p>
              {job.salary && (
                <p style={{ color: "var(--text-light)", fontSize: "0.9rem", marginBottom: "4px" }}>
                  💰 {job.salary}
                </p>
              )}
              <p style={{ fontSize: "0.85rem", color: "#888", marginTop: "8px", marginBottom: "12px" }}>
                {job.description.substring(0, 100)}...
              </p>
              <button
                onClick={() => applyToJob(job.id)}
                disabled={applying === job.id || applied.has(job.id)}
                style={{
                  width: "100%",
                  padding: "10px",
                  background: applied.has(job.id) ? "#e8f5e9" : "var(--primary-color)",
                  color: applied.has(job.id) ? "#2e7d32" : "white",
                  border: "none",
                  borderRadius: "8px",
                  fontWeight: 600,
                  cursor: applied.has(job.id) ? "default" : "pointer",
                  marginTop: "auto",
                }}
              >
                {applying === job.id
                  ? "Applying..."
                  : applied.has(job.id)
                  ? "✓ Applied"
                  : "Apply Now"}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
