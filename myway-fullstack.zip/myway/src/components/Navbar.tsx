"use client";
import { signOut } from "next-auth/react";
import Link from "next/link";

interface NavbarProps {
  user: any;
}

export default function Navbar({ user }: NavbarProps) {
  const role = user?.role?.toLowerCase();

  return (
    <nav className="navbar">
      <Link href={`/dashboard/${role}`} style={{ textDecoration: "none" }}>
        <div className="logo">Myway<span>.</span></div>
      </Link>

      <div style={{ display: "flex", alignItems: "center", gap: "1.5rem" }}>
        <span style={{ color: "var(--text-light)", fontSize: "0.9rem" }}>
          {user?.name}
          <span
            style={{
              marginLeft: "8px",
              background: "#e1f0ff",
              color: "var(--primary-color)",
              padding: "2px 8px",
              borderRadius: "12px",
              fontSize: "0.75rem",
              fontWeight: 700,
              textTransform: "capitalize",
            }}
          >
            {user?.role?.toLowerCase()}
          </span>
        </span>

        <button
          onClick={() => signOut({ callbackUrl: "/" })}
          style={{
            width: "auto",
            padding: "8px 16px",
            background: "transparent",
            color: "var(--error)",
            border: "1px solid var(--error)",
            borderRadius: "8px",
            cursor: "pointer",
            fontSize: "0.9rem",
            fontWeight: 600,
          }}
        >
          Logout
        </button>
      </div>
    </nav>
  );
}
