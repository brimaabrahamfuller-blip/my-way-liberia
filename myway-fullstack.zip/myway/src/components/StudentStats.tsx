interface Props {
  applications: any[];
}

export default function StudentStats({ applications }: Props) {
  const total = applications.length;
  const interviews = applications.filter(a => a.status === "interview").length;
  const accepted = applications.filter(a => a.status === "accepted").length;

  const stats = [
    { label: "Applications Sent", value: total, color: "#004a99" },
    { label: "Interviews", value: interviews, color: "#f5a623" },
    { label: "Accepted", value: accepted, color: "#2e7d32" },
  ];

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
        gap: "16px",
        marginBottom: "2rem",
      }}
    >
      {stats.map(stat => (
        <div
          key={stat.label}
          className="card-item"
          style={{ textAlign: "center", padding: "1.5rem" }}
        >
          <p
            style={{
              fontSize: "2.5rem",
              fontWeight: 800,
              color: stat.color,
              lineHeight: 1,
              marginBottom: "8px",
            }}
          >
            {stat.value}
          </p>
          <p style={{ color: "var(--text-light)", fontSize: "0.85rem" }}>
            {stat.label}
          </p>
        </div>
      ))}
    </div>
  );
}
