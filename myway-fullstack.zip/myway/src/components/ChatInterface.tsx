"use client";
import { useState, useRef, useEffect } from "react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function ChatInterface({ userId }: { userId: string }) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Hi! I'm your Myway AI Career Coach. I can help you with career advice, resume tips, interview prep, job search strategy, and more. What can I help you with today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: Message = { role: "user", content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    // Add empty assistant message to stream into
    setMessages(prev => [...prev, { role: "assistant", content: "" }]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        }),
      });

      if (!res.ok) throw new Error("AI request failed");
      if (!res.body) throw new Error("No response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        accumulated += chunk;

        // Update last (assistant) message with streamed content
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1] = {
            role: "assistant",
            content: accumulated,
          };
          return updated;
        });
      }
    } catch (err) {
      setMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = {
          role: "assistant",
          content: "Sorry, I had trouble responding. Please try again.",
        };
        return updated;
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="chat-container">
      <div className="chat-messages">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`message ${msg.role === "assistant" ? "ai-message" : "user-message"}`}
          >
            {msg.role === "assistant" && (
              <p
                style={{
                  fontSize: "0.75rem",
                  fontWeight: 700,
                  color: "var(--primary-color)",
                  marginBottom: "4px",
                }}
              >
                🤖 Myway AI Coach
              </p>
            )}
            <p style={{ whiteSpace: "pre-wrap", margin: 0 }}>
              {msg.content}
              {loading && i === messages.length - 1 && msg.role === "assistant" && (
                <span
                  style={{
                    display: "inline-block",
                    width: "8px",
                    height: "14px",
                    background: "var(--primary-color)",
                    marginLeft: "2px",
                    animation: "blink 1s infinite",
                    verticalAlign: "text-bottom",
                  }}
                />
              )}
            </p>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={sendMessage} className="chat-input-area">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask your AI career coach anything..."
          disabled={loading}
          style={{ margin: 0, flex: 1 }}
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          style={{
            width: "auto",
            margin: 0,
            padding: "0 24px",
            background: "var(--secondary-color)",
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? <span className="spinner" /> : "Send"}
        </button>
      </form>

      <style>{`
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}
