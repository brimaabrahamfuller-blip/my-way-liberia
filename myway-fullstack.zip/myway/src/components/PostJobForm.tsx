"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PostJobForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    title: "",
    company: "",
    location: "",
    type: "Full-time",
    description: "",
    salary: "",
  });

  function update(field: string, value: string) {
    setForm(prev => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Failed");
      setSuccess(true);
      setForm({ title: "", company: "", location: "", type: "Full-time", description: "", salary: "" });
      router.refresh();
    } catch {
      alert("Could not post job. Please try again.");
    }
    setLoading(false);
  }

  const inputStyle = {
    width: "100%",
    padding: "12px",
    border: "1px solid #dfe6e9",
    borderRadius: "8px",
    fontSize: "1rem",
    marginBottom: "12px",
  };

  return (
    <div className="card-item" style={{ maxWidth: "600px" }}>
      {success && (
        <div style={{ background: "#e8f5e9", color: "#2e7d32", padding: "12px 16px", borderRadius: "8px", marginBottom: "16px", fontWeight: 600 }}>
          ✓ Job posted successfully!
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <input style={inputStyle} placeholder="Job Title *" value={form.title} onChange={e => update("title", e.target.value)} required />
        <input style={inputStyle} placeholder="Company Name *" value={form.company} onChange={e => update("company", e.target.value)} required />
        <input style={inputStyle} placeholder="Location (e.g. Kigali, Rwanda / Remote) *" value={form.location} onChange={e => update("location", e.target.value)} required />
        <select style={inputStyle} value={form.type} onChange={e => update("type", e.target.value)}>
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Remote">Remote</option>
          <option value="Internship">Internship</option>
          <option value="Contract">Contract</option>
        </select>
        <input style={inputStyle} placeholder="Salary (optional, e.g. $500-$800/month)" value={form.salary} onChange={e => update("salary", e.target.value)} />
        <textarea
          style={{ ...inputStyle, minHeight: "120px", resize: "vertical" }}
          placeholder="Job description (requirements, responsibilities, etc.) *"
          value={form.description}
          onChange={e => update("description", e.target.value)}
          required
          minLength={10}
        />
        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? "Posting..." : "Post Job"}
        </button>
      </form>
    </div>
  );
}
